package human01;

public class HumanExam04 {

	public static void main(String[] args) {
		int human = 99;
//		int result = human++ * 10;
		int result = ++human * 10;
		String human1 = "human = " + human;
		System.out.println(human1);
		System.out.println("result =" + result);
		
		
		
	}
}
