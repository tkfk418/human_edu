package human01;

public class HumanExam01 {

	public static void main(String[] args) {
		System.out.println("HELLO HUMAN");
	
		/*
		System.out.println("Hello Human2");
		System.out.println("Hello Human3");
		*/
	
		System.out.println("Hello Human4");
		
		int kor = 100;
		int eng = 90;
		int math = 95;
		
		System.out.println (kor+eng+math);
		
		
	}
}
