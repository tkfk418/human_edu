package human03;

public class HumanExam05_1 {

	public static void main(String[] args) {
		char grade = 'A';
		if (grade == 'A') {
			System.out.println ("당신은 VIP 회원입니다.");
		}
		else if (grade == 'B') {
			System.out.println ("당신은 일반회원입니다.");
		}
		else  {
			System.out.println ("당신은 비회원입니다.");
		}
		System.out.println ("프로그램을 종료합니다.");
		
	}

}
