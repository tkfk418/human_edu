package human03;

public class humanExam02 {

	public static void main(String[] args) {
		int kor = 50;
		System.out.printf("점수 = %d \n", kor);
		
		if (kor >=60 ) {
			// 실행문 1 
			System.out.println("합격하셨습니다.");
		}
		else {
			// 실행문 2
			System.out.println("불합격하셨습니다.");
		}
		System.out.println("프로그램 종료합니다.");
	}

}
