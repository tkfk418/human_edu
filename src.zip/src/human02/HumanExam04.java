package human02;

public class HumanExam04 {

	public static void main(String[] args) {
		int human1 = 100;
		boolean result1 = (human1>80);
		System.out.printf("result1 = %b \n", result1);
		
		boolean result2 = (human1<80);
		System.out.printf("result2 = %b \n", result2);
		
		boolean result3 = (human1<=100);
		System.out.printf("result3 = %b \n", result3);
		
		boolean result4 = (human1 == 100);
		System.out.printf("result4 = %b \n", result4);
		
		boolean result5 = (human1 != 100);
		System.out.printf("result5 = %b \n", result5);
		
		boolean result6 = (human1 != 80);
		System.out.printf("result6 = %b \n", result6);
		
		
		
		
		
		
	}

}
