package human02;

public class HumanExam07 {

	public static void main(String[] args) {
		int score= 100;
		char grade = (score>90) ? 'A' : 'B';
		
		System.out.printf("score = %d, grade = %c \n", score, grade);
		
	}

}
